﻿using System;
using System.Net;
using System.Web;

namespace DossAttack
{
	class Program
	{
		public static void Main(string[] args)
		{
			for (  ;  ;  )
			{
				Console.WriteLine("Write URL:(eg.http://hilina.sn)");
				string y = Console.ReadLine();
				while (true)
				{
					try
					{
					HttpWebRequest requset = (HttpWebRequest)HttpWebRequest.Create(y);
					Console.WriteLine(y);
					}
					catch (Exception ex)
					{
					Console.WriteLine(ex.Message);
					break;
					}

				}
			}
		}
	}
}
